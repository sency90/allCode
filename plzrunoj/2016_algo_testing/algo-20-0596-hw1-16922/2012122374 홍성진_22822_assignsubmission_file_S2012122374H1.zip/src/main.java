import java.util.*;

public class main {
	static int num;
	static int preindex = 0; //preorder �ε���
	static int postindex = 0; //postOrder �ε���
	static int[] preOrder;
	static int[] postOrder;
	static LinkedTree tree = new LinkedTree();
	static TreeNode root = new TreeNode(); //root
	static TreeNode temp = root;
	
	
	public static boolean isBlank(char blank){ //������ Ȯ��
		if(blank == ' ') return true;
		else return false;
	}
	
	public static void convert (int nodeNum, int[] pre, int[] post){
		
		
		preOrder = pre;
		postOrder = post;
		
		root = tree.maketree(null, preOrder[preindex], null);
		TreeNode tt = root;
		
		
		for(preindex = 0; preindex < num; preindex++){
			
			for(int i=0; i<num; i++){ //postindex�� ã�� ����
				if(preOrder[preindex] == postOrder[i]) postindex = i;
			}
			
			if(postindex == 0) {
				for(TreeNode ptr=root; ptr.left.data != postOrder[0]; ptr = ptr.left)
					tt = ptr.left;
				
				tt.left = null;
				tt.right = null;
			}
			else if(tree.searchtree(root, postOrder[postindex-1])) {}
			
			else if(tree.searchtree(root, preOrder[preindex+1])) {System.out.println("ã��preindex�� : "+preOrder[preindex]);}
			
			else {
				if(preindex <= num/2){
					for(TreeNode ptr=root; ptr.left != null; ptr = ptr.left)
						tt = ptr.left;
					
					TreeNode temp1 = tree.maketree(null, preOrder[preindex+1], null);
					TreeNode temp2 = tree.maketree(null, postOrder[postindex-1], null);
					
					tt.left = temp1;
					tt.right = temp2;
					
					System.out.println();
					tree.inorder(root);
					System.out.println();
				}
				else {
					for(TreeNode ptr=root; ptr.right != null; ptr = ptr.right)
						tt = ptr.right;
					
					TreeNode temp1 = tree.maketree(null, preOrder[preindex+1], null);
					TreeNode temp2 = tree.maketree(null, postOrder[postindex-1], null);
					
					tt.left = temp1;
					tt.right = temp2;
					
					System.out.println();
					tree.inorder(root);
					System.out.println();
				}
			}
			
		}
		System.out.println();
		tree.inorder(root);
		System.out.println();
		tt = root;
		
		/*for(preindex = (num-1)/2+1; preindex < num; preindex++){
			
			for(int i=0; i<num; i++){ //postindex�� ã�� ����
				if(preOrder[preindex] == postOrder[i]) postindex = i;
			}

			System.out.println("preindex : " + preindex);
			System.out.println("postindex : "+postindex);
			
			if(postindex == 0) {
				for(TreeNode ptr=root; ptr.left.data != postOrder[0]; ptr = ptr.left)
					tt = ptr;
				tt.left = null;
				tt.right = null;
			}
			
			else if(tree.searchtree(root, preOrder[preindex+1])) {
				System.out.println("ã�� �����Ͱ�???? "+preOrder[preindex+1]);
				System.out.println("preindex : " + preindex);
				System.out.println("postindex : "+postindex);
				
			}
			
			else {
				
				for(TreeNode ptr=root; ptr.left != null; ptr = ptr.left)
					tt = ptr.left;
				
				TreeNode temp1 = tree.maketree(null, preOrder[preindex+1], null);
				TreeNode temp2 = tree.maketree(null, postOrder[postindex-1], null);
				
				tt.left = temp1;
				tt.right = temp2;
				
				System.out.println("preindex : " + preindex);
				System.out.println("postindex : "+postindex);
				
				//System.out.println(tt.left.data + " " + tt.right.data);
				//tree.inorder(root);
				//System.out.println();
			}
			
			
		}
		*/
	}
	
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		Scanner scan0 = new Scanner(System.in);
		Scanner scan1 = new Scanner(System.in);
		Scanner scan2 = new Scanner(System.in);
		
		
		num = scan0.nextInt();
		
		int[] input1 = new int[num*2];
		int[] input2 = new int[num*2];
		for(int i=0; i<num; i++)
			input1[i] = scan1.nextInt();
		for(int i=0; i<num; i++)
			input2[i] = scan2.nextInt();
		
		convert(num, input1, input2);
		
		//tree.inorder(root);
	}

}
