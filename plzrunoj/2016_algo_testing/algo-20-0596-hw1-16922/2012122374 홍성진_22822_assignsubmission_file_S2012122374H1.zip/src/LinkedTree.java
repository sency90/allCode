
public class LinkedTree {
    private TreeNode root;
    
    public TreeNode maketree(TreeNode bt1, int data, TreeNode bt2){
        TreeNode root = new TreeNode(data);
        root.left = bt1;
        root.right = bt2;
        return root;
    }
    
    public TreeNode makeleft(TreeNode bt1, int data){
    	TreeNode root = new TreeNode(data);
    	root.left = bt1;
    	root.right = null;
    	return root;
    }
    
    public TreeNode makeright(TreeNode bt1, int data){
    	TreeNode root = new TreeNode(data);
    	root.left = null;
    	root.right = bt1;
    	return root;
    }
    
    public boolean searchtree(TreeNode temp, int d){ //Ʈ���� �̹� ����ִ� ����������� ã�� �޼ҵ�
    	
    	if(temp.data == d)
    		return true;
    	else
    	{
    		if(temp.left != null && searchtree(temp.left, d)) return true;
    		else if(temp.right != null && searchtree(temp.right, d)) return true;
    		else return false;
    	}
    		
    	
    	
    	
    	/*if(temp.data == d)
    		return true;
    	
    	else if(temp.left != null){
    		searchtree(temp.left, d);
    		searchtree(temp.right, d);
    	}
    	else if(temp.right != null)
    		searchtree(temp.right, d);
    	
    	return false;*/
    	
    	
    }
    
    public void inorder(TreeNode root){
        if(root!=null){
            inorder(root.left);
            System.out.print(root.data + " ");
            inorder(root.right);
        }
    }
    
}